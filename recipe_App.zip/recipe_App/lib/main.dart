import 'package:flutter/material.dart';
import 'models/recipe.dart';
import 'screens/add_recipe_screen.dart';

void main() {
  runApp(RecipeApp());
}

class RecipeApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Recipe App',
      theme: ThemeData(primarySwatch: Colors.red),
      home: RecipeListScreen(),
    );
  }
}

class RecipeListScreen extends StatefulWidget {
  @override
  _RecipeListScreenState createState() => _RecipeListScreenState();
}

class _RecipeListScreenState extends State<RecipeListScreen> {
  List<Recipe> _recipes = [
    Recipe(
      id: 'r1',
      name: 'Sample Recipe Biryani',
      cookingTime: 50,
      difficulty: 'Medium',
      imagePath: 'assets/images/biryani.png',
    ),
  ];

  bool _showFavoritesOnly = false;

  void _toggleFavorite(String id) {
    setState(() {
      final index = _recipes.indexWhere((recipe) => recipe.id == id);
      if (index != -1) {
        _recipes[index].isFavorite = !_recipes[index].isFavorite;
      }
    });
  }

  void _addRecipe(Recipe recipe) {
    setState(() {
      _recipes.add(recipe);
    });

    // Show SnackBar after adding the recipe
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('Recipe "${recipe.name}" added successfully!'),
        duration: Duration(seconds: 2),
        behavior: SnackBarBehavior.floating,
        backgroundColor: Colors.green,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final displayedRecipes = _showFavoritesOnly
        ? _recipes.where((r) => r.isFavorite).toList()
        : _recipes;

    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Recipes',
          style: TextStyle(
              color: const Color.fromARGB(255, 90, 52, 243), fontSize: 25),
        ),
        actions: [
          IconButton(
            icon: Icon(
                _showFavoritesOnly ? Icons.favorite : Icons.favorite_border),
            onPressed: () {
              setState(() {
                _showFavoritesOnly = !_showFavoritesOnly;
              });
            },
          )
        ],
      ),
      body: ListView.builder(
        padding:
            EdgeInsets.only(bottom: 80), // Ensures FAB does not block content
        itemCount: displayedRecipes.length,
        itemBuilder: (ctx, index) {
          final recipe = displayedRecipes[index];
          return Card(
            margin: EdgeInsets.all(10),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(15)),
            child: Container(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(15),
                gradient: LinearGradient(
                  colors: [
                    const Color.fromARGB(255, 255, 194, 194),
                    const Color.fromARGB(255, 242, 213, 168)
                  ],
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                ),
              ),
              child: ListTile(
                contentPadding: EdgeInsets.all(10),
                leading: ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: Image.asset(recipe.imagePath,
                      width: 50, height: 50, fit: BoxFit.cover),
                ),
                title: Text(
                  recipe.name,
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                subtitle: Text(
                  '${recipe.cookingTime} min - ${recipe.difficulty}',
                  style: TextStyle(color: Colors.black87),
                ),
                trailing: IconButton(
                  icon: Icon(
                    recipe.isFavorite ? Icons.favorite : Icons.favorite_border,
                    color: recipe.isFavorite ? Colors.red : null,
                  ),
                  onPressed: () => _toggleFavorite(recipe.id),
                ),
              ),
            ),
          );
        },
      ),
      floatingActionButton: Padding(
        padding: EdgeInsets.only(bottom: 20), // Moves FAB slightly up
        child: FloatingActionButton(
          child: Icon(Icons.add),
          onPressed: () async {
            final newRecipe = await Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => AddRecipeScreen()),
            );
            if (newRecipe != null) {
              _addRecipe(newRecipe);
            }
          },
        ),
      ),
      floatingActionButtonLocation:
          FloatingActionButtonLocation.centerDocked, // Better positioning
    );
  }
}
