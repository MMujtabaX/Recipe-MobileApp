import 'package:flutter/material.dart';
import '../models/recipe.dart';

class AddRecipeScreen extends StatefulWidget {
  @override
  _AddRecipeScreenState createState() => _AddRecipeScreenState();
}

class _AddRecipeScreenState extends State<AddRecipeScreen> {
  final _formKey = GlobalKey<FormState>();
  String _name = '';
  int _cookingTime = 0;
  String _difficulty = 'Easy';
  String _imageName = '';
  bool _isSubmitting = false;
  final List<String> difficultyLevels = ['Easy', 'Medium', 'Hard'];

  void _saveRecipe() {
    if (_formKey.currentState!.validate()) {
      setState(() {
        _isSubmitting = true;
      });

      _formKey.currentState!.save();

      final imagePath = 'assets/images/${_imageName.toLowerCase()}.png';

      final newRecipe = Recipe(
        id: DateTime.now().toString(),
        name: _name,
        cookingTime: _cookingTime,
        difficulty: _difficulty,
        imagePath: imagePath,
      );

      Navigator.pop(context, newRecipe);
    }
  }

  void _cancelRecipe() {
    Navigator.pop(context);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(
          'Add Recipe',
          style: TextStyle(
            color: Color.fromARGB(255, 74, 99, 237),
          ),
        ),
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              const Color.fromARGB(255, 255, 209, 224),
              const Color.fromARGB(255, 230, 144, 173),
            ],
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
          ),
        ),
        child: Center(
          child: SingleChildScrollView(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(15),
                ),
                elevation: 5,
                child: Container(
                  padding: EdgeInsets.all(16),
                  decoration: BoxDecoration(
                    color: Color.fromARGB(255, 118, 48, 167), // Dark Purple
                    borderRadius: BorderRadius.circular(15),
                  ),
                  child: Form(
                    key: _formKey,
                    child: Column(
                      children: [
                        TextFormField(
                          decoration: InputDecoration(
                            labelText: 'Recipe Name',
                            labelStyle: TextStyle(color: Colors.white),
                            border: OutlineInputBorder(),
                            prefixIcon:
                                Icon(Icons.food_bank, color: Colors.white),
                            filled: true,
                            fillColor: Colors.white24,
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.white),
                            ),
                          ),
                          style: TextStyle(color: Colors.white),
                          validator: (value) {
                            if (value!.isEmpty)
                              return 'Please enter a recipe name';
                            return null;
                          },
                          onSaved: (value) => _name = value!,
                        ),
                        SizedBox(height: 10),
                        TextFormField(
                          decoration: InputDecoration(
                            labelText: 'Cooking Time (in minutes)',
                            labelStyle: TextStyle(color: Colors.white),
                            border: OutlineInputBorder(),
                            prefixIcon: Icon(Icons.timer, color: Colors.white),
                            filled: true,
                            fillColor: Colors.white24,
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.white),
                            ),
                          ),
                          style: TextStyle(color: Colors.white),
                          keyboardType: TextInputType.number,
                          validator: (value) {
                            if (value!.isEmpty || int.tryParse(value) == null) {
                              return 'Enter a valid number';
                            }
                            return null;
                          },
                          onSaved: (value) => _cookingTime = int.parse(value!),
                        ),
                        SizedBox(height: 10),
                        DropdownButtonFormField(
                          decoration: InputDecoration(
                            labelText: 'Difficulty',
                            labelStyle: TextStyle(color: Colors.white),
                            border: OutlineInputBorder(),
                            filled: true,
                            fillColor: Colors.white24,
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.white),
                            ),
                          ),
                          dropdownColor: Color.fromARGB(255, 80, 118, 255),
                          value: _difficulty,
                          items: difficultyLevels
                              .map((level) => DropdownMenuItem(
                                    value: level,
                                    child: Text(level,
                                        style: TextStyle(color: Colors.white)),
                                  ))
                              .toList(),
                          onChanged: (value) =>
                              setState(() => _difficulty = value!),
                          style: TextStyle(color: Colors.white),
                        ),
                        SizedBox(height: 10),
                        TextFormField(
                          decoration: InputDecoration(
                            labelText: 'Image Name (without extension)',
                            labelStyle: TextStyle(color: Colors.white),
                            border: OutlineInputBorder(),
                            prefixIcon: Icon(Icons.image, color: Colors.white),
                            filled: true,
                            fillColor: Colors.white24,
                            focusedBorder: OutlineInputBorder(
                              borderSide: BorderSide(color: Colors.white),
                            ),
                          ),
                          style: TextStyle(color: Colors.white),
                          validator: (value) {
                            if (value!.isEmpty) return 'Enter an image name';
                            return null;
                          },
                          onSaved: (value) => _imageName = value!,
                        ),
                        SizedBox(height: 20),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [
                            ElevatedButton.icon(
                              onPressed: _isSubmitting ? null : _saveRecipe,
                              icon: Icon(Icons.check),
                              label: Text('Save Recipe'),
                              style: ElevatedButton.styleFrom(
                                padding: EdgeInsets.symmetric(horizontal: 20),
                                backgroundColor:
                                    const Color.fromARGB(255, 136, 234, 139),
                              ),
                            ),
                            OutlinedButton.icon(
                              onPressed: _cancelRecipe,
                              icon: Icon(Icons.cancel),
                              label: Text('Cancel'),
                              style: OutlinedButton.styleFrom(
                                padding: EdgeInsets.symmetric(horizontal: 20),
                                foregroundColor:
                                    const Color.fromARGB(255, 255, 85, 73),
                                side: BorderSide(
                                    color:
                                        const Color.fromARGB(255, 250, 77, 64)),
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
