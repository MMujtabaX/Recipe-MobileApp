class Recipe {
  final String id;
  final String name;
  final int cookingTime; // in minutes
  final String difficulty; // Easy, Medium, Hard
  final String imagePath; // Local image path
  bool isFavorite;

  Recipe({
    required this.id,
    required this.name,
    required this.cookingTime,
    required this.difficulty,
    required this.imagePath,
    this.isFavorite = false,
  });
}
